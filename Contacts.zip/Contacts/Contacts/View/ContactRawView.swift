//
//  ContactRawView.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import SwiftUI

struct ContactRawView: View {
    var data: Contact
    
    var body: some View {
        HStack {
            Text(data.placeHolder)
                .font(.headline)
                .frame(width: 40, height: 40)
                .padding(10)
                .background(Color.gray.opacity(0.5))
                .clipShape(Circle())
            
            VStack(alignment: .leading) {
                Text(data.firstName)
                Text(data.lastName)
                    .foregroundStyle(.gray)
            }
        }
    }
}
