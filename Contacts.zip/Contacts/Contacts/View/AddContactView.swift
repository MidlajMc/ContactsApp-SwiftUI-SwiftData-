//
//  AddContactView.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import SwiftUI
import SwiftData

struct AddContactView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var phone = ""
    
    var body: some View {
        Form {
            Section("Add Contact") {
                TextField("First Name", text: $firstName)
                TextField("Last Name", text: $lastName)
                TextField("Email", text: $email)
                TextField("Phone", text: $phone)
            }
            
            Button("Save") {
                let contact = Contact(
                    firstName: firstName,
                    lastName: lastName,
                    email: email,
                    phone: phone
                )
                
                context.insert(contact)
                dismiss()
            }
        }
        .navigationTitle("New Contact")
        .navigationBarTitleDisplayMode(.inline)
    }
}
