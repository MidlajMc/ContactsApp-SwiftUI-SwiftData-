//
//  EditContentView.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import SwiftUI
import SwiftData

struct EditContactView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    
    var contact: Contact
    
    var body: some View {
        Form {
            Section("Edit Contact") {
                TextField("First Name", text: Binding(
                    get: { contact.firstName },
                    set: { contact.firstName = $0 }
                ))
                
                TextField("Last Name", text: Binding(
                    get: { contact.lastName },
                    set: { contact.lastName = $0 }
                ))
                
                TextField("Email", text: Binding(
                    get: { contact.email },
                    set: { contact.email = $0 }
                ))
                
                TextField("Phone", text: Binding(
                    get: { contact.phone },
                    set: { contact.phone = $0 }
                ))
            }
            
            Button("Delete Contact", role: .destructive) {
                context.delete(contact)
                dismiss()
            }
        }
        .navigationTitle("Edit Contact")
        .navigationBarTitleDisplayMode(.inline)
    }
}
