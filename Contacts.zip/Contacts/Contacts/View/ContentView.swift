//
//  ContentView.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var context
    
    @Query private var contacts: [Contact]
    
    @State private var searchText = ""
    
    var filteredContacts: [Contact] {
        if searchText.isEmpty {
            return contacts
        } else {
            return contacts.filter {
                $0.firstName.localizedCaseInsensitiveContains(searchText) ||
                $0.lastName.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(filteredContacts) { contact in
                    NavigationLink(value: contact) {
                        ContactRawView(data: contact)
                    }
                }
                .onDelete { indexSet in
                    indexSet.map { filteredContacts[$0] }.forEach {
                        context.delete($0)
                    }
                }
            }
            .searchable(text: $searchText)
            .navigationTitle("Contacts")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        AddContactView()
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .navigationDestination(for: Contact.self) { contact in
                EditContactView(contact: contact)
            }
        }
    }
}

#Preview {
    ContentView()
}
