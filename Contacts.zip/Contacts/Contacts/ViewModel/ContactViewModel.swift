//
//  ContactViewModel.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import Foundation

@Observable
class ContactViewModel {
    var contacts: [Contact] = []
    
    init() {
        fetchContacts()
    }
    
    func fetchContacts() {
        contacts = [
            Contact(
                id: UUID(),
                firstName: "Midlaj",
                lastName: "Mc",
                email: "midlaj@gmail.com",
                phone: "0789543210"
            ),
            Contact(
                id: UUID(),
                firstName: "John",
                lastName: "Snow",
                email: "john@gmail.com",
                phone: "0789543211"
            )
        ]
    }
    
    func addContact(_ contact: Contact) {
        contacts.append(contact)
    }
    
    func deleteContact(_ contact: Contact) {
        contacts.removeAll { $0.id == contact.id }
    }
    
    func updateContact(_ updated: Contact) {
        if let index = contacts.firstIndex(where: { $0.id == updated.id }) {
            contacts[index] = updated
        }
    }
}
