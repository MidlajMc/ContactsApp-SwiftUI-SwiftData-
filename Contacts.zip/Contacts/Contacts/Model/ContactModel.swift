//
//  ContactModel.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import Foundation
import SwiftData

@Model
class Contact {
    var id: UUID
    var firstName: String
    var lastName: String
    var email: String
    var phone: String
    
    init(id: UUID = UUID(),
         firstName: String,
         lastName: String,
         email: String,
         phone: String) {
        self.id = id
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.phone = phone
    }
    
    var placeHolder: String {
        let first = firstName.prefix(1)
        let last = lastName.prefix(1)
        return String(first + last)
    }
}
