//
//  ContactsApp.swift
//  Contacts
//
//  Created by Midlaj Mc on 27/04/26.
//

import SwiftUI
import SwiftData

@main
struct ContactsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: Contact.self)
    }
}
